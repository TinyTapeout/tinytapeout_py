import logging

class project()

    def __init__(self):
        pass
    
    def __str__(self):
        logging.info("I'm a module")        
